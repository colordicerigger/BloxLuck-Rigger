document.getElementById("predictBtn").addEventListener("click", () => {
  const isHeads = Math.random() < 0.5;
  const resultImg = document.getElementById("resultImg");

  // Set image and alt text based on result
  resultImg.src = isHeads ? "Assets/kirmizi.png" : "Assets/mavi.png";
  resultImg.alt = isHeads ? "H" : "T";
  resultImg.classList.remove("hidden");
});
